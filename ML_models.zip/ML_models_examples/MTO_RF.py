# -*- coding: utf-8 -*-
"""
Created on 2023

@author: Zhu, L.T.
If the following code is used, please cite our corresponding publications:
    https://scholar.google.com/citations?user=ZojFcCQAAAAJ&hl=zh-CN&oi=ao
"""

import  tensorflow as tf #给引入的包tensorflow定义一个别名tf
import  os #导入标准库os
import h5py #存放数据集(dataset)和组(group)的容器
import numpy as np #导入NumPy函数库

import matplotlib.pyplot as plt #绘图
import pandas as pd #Pandas纳入了大量库和一些标准的数据模型，数据分析任务

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
import joblib



os.environ['TF_CPP_MIN_LOG_LEVEL']='2' 
#log信息共有四个等级，按重要性递增为：INFO（通知,0）<WARNING（警告,1）<ERROR（错误,2）<FATAL（致命的,3）;
tf.random.set_seed(2345) # 全局种子

def preprocess(x, y):
    # [-1~1]

    x = tf.cast(x, dtype=tf.float32) #dtype元素的类型;张量数据类型转换
    y = tf.cast(y, dtype=tf.float32)
 
    return x,y

def computeCorrelation(x, y): # X：皮尔逊相关系数；y：R2，确定系数
    
    xBar = np.mean(x) #均值
    yBar = np.mean(y)
    diffxxBar = x-xBar
    diffyyBar = y-yBar
    SSR = diffxxBar*diffyyBar
    dif=x-y
    return np.sum(SSR)/(np.sum((diffxxBar*diffxxBar))*np.sum((diffyyBar*diffyyBar)))**0.5, 1-np.sum((dif)**2)/np.sum(diffyyBar**2)

#数据读取
data = pd.read_csv("MTO.csv") 
data = np.array(data) #产生数组
#data[:,4]=10**(-data[:,4]) #第5列的每个元素取10的负次方

data[:,0]=(data[:,0]-0.0)/(0.5-0.0) #归一化,bed height
data[:,1]=(data[:,1]-0.610624)/(1.0-0.610624) #(D2-d2)/D2,Catalyst particle volumber
data[:,2]=(data[:,2]-0)/(7-0) #Number of holes
data[:,3]=(data[:,3]-0.1111111)/(0.6666667-0.1111111) #inlet mole ratio ch3oh/H2O
data[:,4]=(data[:,4]-1)/(4.5-1) #inlet velocity
data[:,5]=(data[:,5]-648)/(748-648) #inlet temperature
data[:,6]=(data[:,6]-4)/(7-4) #coke content
data[:,7]=data[:,7]


xa = data[:,:7] #1到5列每一行赋给xa
ya = data[:,[7]] #二维，形状很重要;数组形式

permutation = np.random.permutation(xa.shape[0]) #打乱序号
xa = xa[permutation, :] #x打乱
ya = ya[permutation,:] #y打乱

n=xa.shape[0] #各维度的尺度
print(n)
x, x_val = tf.split(xa, num_or_size_splits=[int(n*0.8),-1])
y, y_val = tf.split(ya, num_or_size_splits=[int(n*0.8), -1]) #-1是缺省；分成0.8:0.2两份；中括号向量决定了分割的维度

n1 = x.shape[0]
n2 = x_val.shape[0]
xnumb = x.shape[1]


# 初始化XGBoost回归模型
model = RandomForestRegressor(max_depth=10,n_estimators=25)


#lr：float> = 0.学习率；
#beta_1：float，0 <beta <1。一般接近1。一阶矩估计的指数衰减率
#beta_2：float，0 <beta <1。一般接近1。二阶矩估计的指数衰减率
#epsilon：float> = 0,模糊因子。如果None，默认为K.epsilon()。该参数是非常小的数，其为了防止在实现中除以零
#decay：float> = 0,每次更新时学习率下降

#epochs：训练模型迭代次数；validation_freq：每几个时期运行一次验证
#model.fit(train_db, epochs=15000, validation_data=val_db, validation_freq=10)
model.fit(x, y)
joblib.dump(model,'RF.pkl')


py = model.predict(x)
py = py
y2 = y #训练集
n=py.shape[0]
py = np.reshape(py,[n])
y2 = np.reshape(y2,[n])
print(np.mean(np.abs((py-y2)/y2)), computeCorrelation(y2,py))
plt.scatter(y2,py, marker = '.', color = 'r', label='1', s = 1)
plt.show()

py = model.predict(x_val)
py = py
y2 = y_val #验证集
n=py.shape[0]
py = np.reshape(py,[n])
y2 = np.reshape(y2,[n])
print(np.mean(np.abs((py-y2)/y2)), computeCorrelation(y2,py))
plt.scatter(y2,py, marker = '.', color = 'r', label='1', s = 1)
plt.show()
x_val = np.array(x_val)
x_val[:,0] = x_val[:,0]*(0.5-0.0)+0.0 #bed height
x_val[:,1] = x_val[:,1]*(1.0-0.610624)+0.610624 #(D2-d2)/D2,Catalyst particle volumber
x_val[:,2] = x_val[:,2]*(7-0)+0 #(D2-d2)/D2,Catalyst particle volumber
x_val[:,3] = x_val[:,3]*(0.6666667-0.1111111)+0.1111111 #(D2-d2)/D2,Catalyst particle volumber
x_val[:,4] = x_val[:,4]*(4.5-1)+1 #(D2-d2)/D2,Catalyst particle volumber
x_val[:,5] = x_val[:,5]*(748-648)+648 #(D2-d2)/D2,Catalyst particle volumber
x_val[:,6] = x_val[:,6]*(7-4)+4 #(D2-d2)/D2,Catalyst particle volumber

py = np.reshape(py,[n,1])
y2 = np.reshape(y2,[n,1])
dataout = np.concatenate((x_val,y2,py),axis=1)
np.savetxt("val_C2C3Rate_RF.txt", dataout,fmt='%f',delimiter=',')


py = model.predict(xa)
py = py
y2 = ya #所有数据集
n=py.shape[0]
py = np.reshape(py,[n])
y2 = np.reshape(y2,[n])
print(np.mean(np.abs((py-y2)/y2)), computeCorrelation(y2,py))
py = np.reshape(py,[n])
y2 = np.reshape(y2,[n])
xa = np.array(xa)
xa[:,0] = xa[:,0]*(0.5-0.0)+0.0 #bed height
xa[:,1] = xa[:,1]*(1.0-0.610624)+0.610624 #(D2-d2)/D2,Catalyst particle volumber
xa[:,2] = xa[:,2]*(7-0)+0 #(D2-d2)/D2,Catalyst particle volumber
xa[:,3] = xa[:,3]*(0.6666667-0.1111111)+0.1111111 #(D2-d2)/D2,Catalyst particle volumber
xa[:,4] = xa[:,4]*(4.5-1)+1 #(D2-d2)/D2,Catalyst particle volumber
xa[:,5] = xa[:,5]*(748-648)+648 #(D2-d2)/D2,Catalyst particle volumber
xa[:,6] = xa[:,6]*(7-4)+4 #(D2-d2)/D2,Catalyst particle volumber

py = np.reshape(py,[n,1])
y2 = np.reshape(y2,[n,1])
dataout = np.concatenate((xa,y2,py),axis=1)
np.savetxt("all_C2C3Rate_RF.txt", dataout,fmt='%f',delimiter=',')